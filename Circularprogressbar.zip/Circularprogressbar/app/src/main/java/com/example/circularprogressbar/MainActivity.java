package com.example.circularprogressbar;

import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    ProgressBar prg1;
    ProgressBar prg2;
    ProgressBar prg3;
    ProgressBar prg4;
    ProgressBar prg5;
    ProgressBar prg6;

    float prg1_procent = 0;
    float prg2_procent = 0;
    float prg3_procent = 0;
    float prg4_procent = 0;
    float prg5_procent = 0;
    float prg6_procent = 0;
    float geldtotaal = 300;
    float geldrood = 0;
    float geldblauw = 0;
    float geldgroen = 0;
    float geldgeel = 0;
    float geldzwart = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        barlatenzien();
        geldlatenzien();
        //Progresbar regelen

    }
        public void barlatenzien () {


            //regel waardes voor progessbar2
            prg2 = (ProgressBar) findViewById(R.id.progressBar2);
            prg2.getProgressDrawable().setColorFilter(
                    Color.BLUE, android.graphics.PorterDuff.Mode.SRC_IN);
            prg2.setProgress((int) (Math.ceil(prg2_procent)));
            prg2.setRotation((int) (270 + (prg1_procent * 3.60)));


            //regel waardes voor progressbar 3
            prg3 = (ProgressBar) findViewById(R.id.progressBar3);
            prg3.getProgressDrawable().setColorFilter(
                    Color.GREEN, android.graphics.PorterDuff.Mode.SRC_IN);
            prg3.setProgress((int) (Math.ceil(prg3_procent)));
            prg3.setRotation((int) (270 + ((prg1_procent + prg2_procent) * 3.60)));


            //regel waardes voor progressbar 4
            prg4 = (ProgressBar) findViewById(R.id.progressBar4);
            prg4.getProgressDrawable().setColorFilter(
                    Color.YELLOW, android.graphics.PorterDuff.Mode.SRC_IN);
            prg4.setProgress((int) (Math.ceil(prg4_procent)));
            prg4.setRotation((int) (270 + ((prg1_procent + prg2_procent + prg3_procent) * 3.60)));


            //regel waardes voor progressbar 5
            prg5 = (ProgressBar) findViewById(R.id.progressBar5);
            prg5.getProgressDrawable().setColorFilter(
                    Color.BLACK, android.graphics.PorterDuff.Mode.SRC_IN);
            prg5.setProgress((int) (Math.ceil(prg5_procent)));
            prg5.setRotation((int) (270 + ((prg1_procent + prg2_procent + prg3_procent + prg4_procent) * 3.60)));


            //regel waardes voor progressbar 6
            prg6 = (ProgressBar) findViewById(R.id.progressBar6);
            prg6.getProgressDrawable().setColorFilter(
                    Color.MAGENTA, android.graphics.PorterDuff.Mode.SRC_IN);
            prg6.setProgress((int) (Math.ceil(prg6_procent)));
            prg6.setRotation((int) (270 + ((prg1_procent + prg2_procent + prg3_procent + prg4_procent + prg5_procent) * 3.60)));

            // regel waardes voor progressbar 1
            prg1 = (ProgressBar) findViewById(R.id.progressBar);
            prg1.getProgressDrawable().setColorFilter(
                    Color.RED, android.graphics.PorterDuff.Mode.SRC_IN);
            prg1.setProgress((int) (Math.ceil(prg1_procent)));
            prg1.setRotation(270);

        }



    public void geldlatenzien()

    {
        TextView textView = (TextView) findViewById(R.id.geldtotaal);
        textView.setText(String.valueOf(geldtotaal));

        TextView textView2 = (TextView) findViewById(R.id.roodgeld);
        textView2.setText(String.valueOf(geldrood));

        TextView textView3 = (TextView) findViewById(R.id.blauwgeld);
        textView3.setText(String.valueOf(geldblauw));

        TextView textView4 = (TextView) findViewById(R.id.groengeld);
        textView4.setText(String.valueOf(geldgroen));

        TextView textView5 = (TextView) findViewById(R.id.geelgeld);
        textView5.setText(String.valueOf(geldgeel));

        TextView textView6 = (TextView) findViewById(R.id.zwartgeld);
        textView6.setText(String.valueOf(geldzwart));



        // sample
        //ImageView myimageviewgreen = (ImageView) findViewById(R.id.dot1);
        // myimageviewgreen.setImageResource(R.drawable.circle_rood);
}
        public void geldupdaten()
    {
        prg1_procent = ((geldrood/geldtotaal)*100);
        prg2_procent = ((geldblauw/geldtotaal)*100);
        prg3_procent = ((geldgroen/geldtotaal)*100);
        prg4_procent = ((geldgeel/geldtotaal)*100);
        prg5_procent = ((geldzwart/geldtotaal)*100);

    }


    public void onClick(View v) {


        switch (v.getId()) {
            case R.id.geldtotaal:
                geldtotaal += 100;
                geldupdaten();
                geldlatenzien();
                barlatenzien();
                break;
            case R.id.roodgeld:
                // Check of je wel budget hebt
                if (geldrood + geldblauw + geldgroen + geldgeel+ geldzwart < (geldtotaal))
                geldrood += 100;
                prg1_procent = ((geldrood / geldtotaal) * 100);
                geldlatenzien();
                barlatenzien();
                break;
            case R.id.blauwgeld:
                if (geldrood + geldblauw + geldgroen + geldgeel+ geldzwart < (geldtotaal))
                geldblauw += 100;
                prg2_procent = ((geldblauw / geldtotaal) * 100);
                geldlatenzien();
                barlatenzien();
                break;
            case R.id.groengeld:
                if (geldrood + geldblauw + geldgroen + geldgeel+ geldzwart < (geldtotaal))
                geldgroen += 100;
                prg3_procent = ((geldgroen / geldtotaal) * 100);
                geldlatenzien();
                barlatenzien();
                break;
            case R.id.geelgeld:
                if (geldrood + geldblauw + geldgroen + geldgeel+ geldzwart < (geldtotaal))
                geldgeel += 100;
                prg4_procent = ((geldgeel/geldtotaal)*100);
                geldlatenzien();
                barlatenzien();
                break;
            case R.id.zwartgeld:
                if (geldrood + geldblauw + geldgroen + geldgeel+ geldzwart < (geldtotaal));
                geldzwart += 100;
                prg5_procent = ((geldzwart/geldtotaal)*100);
                geldlatenzien();
                barlatenzien();
                break;



                }
            }
        }











